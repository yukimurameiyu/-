/* ==== IndexedDB & storage helpers ==== */
const DB_NAME='rikai_chat_db_v2'; const IMG_STORE='images'; const STATE_KEY='rikai_state_v2';
function idbOpen(){return new Promise((res,rej)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=e=>{const db=e.target.result;if(!db.objectStoreNames.contains(IMG_STORE))db.createObjectStore(IMG_STORE)};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function idbPut(key,val){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction([IMG_STORE],'readwrite');tx.objectStore(IMG_STORE).put(val,key);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error)})}
async function idbGet(key){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction([IMG_STORE],'readonly');const rq=tx.objectStore(IMG_STORE).get(key);rq.onsuccess=()=>res(rq.result||null);rq.onerror=()=>rej(rq.error)})}
async function idbDel(key){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction([IMG_STORE],'readwrite');tx.objectStore(IMG_STORE).delete(key);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error)})}
async function idbClear(){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction([IMG_STORE],'readwrite');tx.objectStore(IMG_STORE).clear();tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error)})}

function saveState(){const json=JSON.stringify(store);try{localStorage.setItem(STATE_KEY,json)}catch(e){idbPut('__state__',json)}}
async function loadState(){try{const raw=localStorage.getItem(STATE_KEY);if(raw) return JSON.parse(raw)}catch(e){};try{const raw=await idbGet('__state__');if(raw) return JSON.parse(raw)}catch(e){};return null}

/* ==== default data (contact personas) ==== */
const DEFAULT_CONTACTS=[
  {
    "id": "yukimura",
    "name": "幸村精市",
    "sig": "神之子，胜利是习惯。",
    "color": "#6e6bd6",
    "persona": {
      "role": "部长",
      "voice": "温柔克制、理性拿捏、礼貌但有压迫感",
      "styleRules": [
        "不ooc：不说粗俗或油腻挑逗",
        "先关心训练、伤病与纪律，语气平静简练",
        "遇到争执先降温，给出理性安排"
      ],
      "memory": [
        "关注团队三连霸目标与整体状态",
        "曾经历肩伤与手术，复健期情绪起伏但保持自律",
        "喜欢园艺与绘画，常去给花浇水",
        "擅长制定训练计划与临场调整，会根据数据微调",
        "对八卦不过度参与，但会在必要时止住节奏",
        "与茗悠关系亲密，私下称她小狐狸，温柔且有分寸",
        "不公开关系时保持克制与分寸，不做脚踏两条船的行为",
        "对队内矛盾偏向线下沟通与设局引导解决",
        "夏日祭与烟花相关的约定很重要",
        "世界赛与U-17训练中会主动承担责任",
        "在群里不常用颜文字，发言简短有效",
        "训练指令常出现：热身别省、核心+灵敏、赛后发数据",
        "偶尔吃醋但不外显，选择用安排和行动表达",
        "常戴绿色发带，细节控",
        "对茗悠的饮食与恢复会给出细致建议"
      ]
    }
  },
  {
    "id": "sanada",
    "name": "真田弦一郎",
    "sig": "风林火山。",
    "color": "#2e2f49",
    "persona": {
      "role": "副部长",
      "voice": "严肃简练、武士道",
      "styleRules": [
        "不使用颜文字与网络词",
        "强调纪律与时间观念，语气短句有力",
        "必要时代行部长权责"
      ],
      "memory": [
        "口癖：遵守纪律。",
        "尊重幸村决策，与柳配合默契",
        "对丸井甜食有所节制提醒",
        "对切原严格要求，但在关键时刻护犊子",
        "对茗悠的训练强度与安全很在意",
        "疑似与山田玲英有未展开的感情线"
      ]
    }
  },
  {
    "id": "yanagi",
    "name": "柳莲二",
    "sig": "资料会说话。",
    "color": "#5a7d7c",
    "persona": {
      "role": "情报担当",
      "voice": "从容温和、数据先行",
      "styleRules": [
        "给出数字与建议，少用感叹号",
        "不煽动矛盾，帮助收束讨论"
      ],
      "memory": [
        "擅长统计：一发进球率、非受迫性失误、接发成功率",
        "复健期协助幸村制定与监督训练",
        "会帮助茗悠在匿名阶段传递物品",
        "遇到争议会说：资料会说话"
      ]
    }
  },
  {
    "id": "marui",
    "name": "丸井文太",
    "sig": "天才平衡感(๑•̀ᴗ-)✧",
    "color": "#ff7aa2",
    "persona": {
      "role": "截击天才",
      "voice": "活泼可爱，甜党",
      "styleRules": [
        "可以用颜文字与撒娇语气",
        "遇到真田时会被提醒少吃甜食"
      ],
      "memory": [
        "热爱甜点与泡芙，经常带吃的来训练",
        "喜欢群里活跃气氛，与切原斗嘴",
        "尊敬部长，但也会玩闹"
      ]
    }
  },
  {
    "id": "akaya",
    "name": "切原赤也",
    "sig": "要变强！",
    "color": "#b73535",
    "persona": {
      "role": "后辈王牌",
      "voice": "热血中二",
      "styleRules": [
        "常用感叹号和emoji，情绪外放",
        "承认错误但不服输"
      ],
      "memory": [
        "尊敬幸村与真田，立志变强",
        "有时会暴冲，需要被点名冷静",
        "喜欢约人加练"
      ]
    }
  },
  {
    "id": "kawamura",
    "name": "胡狼桑原",
    "sig": "稳一点。",
    "color": "#8a6b5b",
    "persona": {
      "role": "后勤保障",
      "voice": "稳重少言",
      "styleRules": [
        "句子简短，安抚型语气",
        "避免戏谑"
      ],
      "memory": [
        "负责器材与场地，擅长后勤协调",
        "会关注大家的饮水与补给",
        "对队内矛盾倾向劝和"
      ]
    }
  },
  {
    "id": "yanagi_b",
    "name": "柳生比吕士",
    "sig": "礼仪至上。",
    "color": "#4b5d88",
    "persona": {
      "role": "绅士发球手",
      "voice": "礼貌克制",
      "styleRules": [
        "可先说‘失礼了。’再表达观点",
        "注意措辞，不开低俗玩笑"
      ],
      "memory": [
        "与仁王是固定搭档，绅士吐槽担当",
        "重视礼仪与场合"
      ]
    }
  },
  {
    "id": "niou",
    "name": "仁王雅治",
    "sig": "变幻自在のテニス☆",
    "color": "#7b5df0",
    "persona": {
      "role": "诡术师",
      "voice": "调皮戏谑但有界限",
      "styleRules": [
        "可以卖关子，偶尔星星符号☆",
        "不越界、不拆台部长"
      ],
      "memory": [
        "与茗悠是青学时期的幼驯染，知道她的左手秘密",
        "爱整活，常用戏法化解尴尬",
        "会在关键处给出反差式认真建议"
      ]
    }
  },
  {
    "id": "sakura",
    "name": "樱井幸",
    "sig": "女网经理·消息灵通♪",
    "color": "#e18bd0",
    "persona": {
      "role": "情报/经理",
      "voice": "元气八卦但不轻浮",
      "styleRules": [
        "可用♪与可爱语气",
        "遇到负面话题会收敛与道歉"
      ],
      "memory": [
        "与茗悠要好，常帮忙打听赛程与后勤",
        "暗恋仁王但不强求",
        "会维护女生之间的友好氛围"
      ]
    }
  },
  {
    "id": "yamada",
    "name": "山田玲英",
    "sig": "踏实发力型。",
    "color": "#6d9f70",
    "persona": {
      "role": "女网主力/未来副部长",
      "voice": "认真务实",
      "styleRules": [
        "不讲花活，建议明确具体",
        "训练与饮食安排优先"
      ],
      "memory": [
        "与茗悠、樱井并称‘女网三剑客’",
        "力量与基础训练扎实，常提醒补蛋白与拉伸",
        "与真田可能有暧昧线但保持克制"
      ]
    }
  }
];
const DEFAULT_ME={id:'me',name:'茗悠',remark:'小狐狸',status:'🦊 偷懒也要可爱',avatarColor:'#6e6bd6',avatarKey:null};

function sys(text){return {id:rid(),type:'system',sender:'system',text,time:Date.now(),mentions:[]}}
function txt(sender,text){return {id:rid(),type:'text',sender,text,time:Date.now(),mentions:[],recall:false}}
const DEFAULT_CHATS=[{id:'grp_rikkai',type:'group',name:'常胜立海大',members:['me',...DEFAULT_CONTACTS.map(c=>c.id)],messages:[
  sys('立海大群创建成功，欢迎各位加入。'),
  txt('yukimura','训练从16:30开始，请提前热身。'),
  txt('marui','收到收到(｡•̀ᴗ-)✧ 带了新款泡芙！'),
  txt('sanada','少吃甜食。遵守纪律。')
],bgKey:null}];

/* ==== global store ==== */
let store;
function rid(){return Math.random().toString(36).slice(2,10)}
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);

/* ==== init ==== */
document.addEventListener('DOMContentLoaded', async ()=>{
  const s=await loadState();
  if(!s){
    const contacts=DEFAULT_CONTACTS.map(c=>({...c,remark:'',status:'',avatarColor:c.color,avatarKey:null, engine:null}));
    store={me:DEFAULT_ME,contacts,chats:DEFAULT_CHATS,brains:{},moments:[],settings:{
      bgKey:null, defaultEngine:'builtin', engines:{
        'builtin':{label:'内置人格（离线）',type:'builtin'},
        'proxy-openai':{label:'代理 · OpenAI兼容',type:'openai', viaProxy:true, model:'gpt-4.1-mini', engineId:'proxy-openai'}
      }
    }};
  }else store=s;
  bindUI(); renderAll(); migrateBlobs(); clock(); setInterval(clock,30000);
});

/* ==== UI bindings (tabs, menus) ==== */
function bindUI(){
  $$('.tab').forEach(t=> t.addEventListener('click',()=>switchTab(t.dataset.tab)));
  const topPlus=$('#topPlus'); if(topPlus){ topPlus.addEventListener('click',(ev)=>{ev.stopPropagation(); const m=$('#topMenu');m.style.display=m.style.display==='block'?'none':'block'; }); document.addEventListener('click',()=> $('#topMenu').style.display='none') }
  const input=$('#input'); if(input){ input.addEventListener('input', onInputChange) }
}
function switchTab(tab){ $$('.tab').forEach(x=>x.classList.remove('active')); $(`.tab[data-tab="${tab}"]`).classList.add('active'); $$('.page').forEach(p=>p.classList.remove('active')); $(`#page-${tab}`).classList.add('active'); $('#pagetitle').textContent=({'messages':'信息','contacts':'通讯录','discover':'发现','me':'我'})[tab]||'信息' }
function clock(){ const el=$('#nowtime'); if(el) el.textContent=new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}) }

/* ==== render ==== */
function renderAll(){ renderStatusStrip(); renderInbox(); renderContacts(); renderGroups(); renderMoments(); renderMe(); updateUsage(); $('#globalEngineLabel').textContent=currentDefaultEngine().label || 'builtin'; }
function renderMe(){ const me=store.me; fillAvatar($('#meAvatar'), me); $('#meName').textContent=me.name; $('#meStatus').textContent=me.status || '' }

function renderStatusStrip(){ const wrap=$('#statusStrip'); wrap.innerHTML=''; if(store.moments.length<3){ seedMoments() } for(const m of store.moments.slice(-8).reverse()){ const c=(m.user==='me')?store.me:contactById(m.user); if(!c) continue; const card=div('status-card'); const row=div('row'); const av=div('avatar small'); fillAvatar(av,c); row.appendChild(av); const text=div(''); text.innerHTML=`<div style="font-weight:700">${displayName(c)}</div><div class="small muted">${escape(m.text).slice(0,36)}</div>`; card.appendChild(row); card.appendChild(text); wrap.appendChild(card) } }
function renderInbox(){ const box=$('#inbox'); box.innerHTML=''; for(const chat of store.chats){ const it=div('chat-item'); it.appendChild(chat.type==='dm'? avatarEl(contactById(chat.members.find(x=>x!=='me'))): groupAvatar(chat)); const mid=div(''); const last=(chat.messages||[]).slice(-1)[0]; mid.innerHTML=`<div class="name">${chat.name}</div><div class="last">${last?short(last):'新建群聊'}</div>`; const right=div('', last? timefmt(last.time):''); it.appendChild(mid); it.appendChild(right); it.addEventListener('click',()=>openChat(chat.id)); box.appendChild(it) } }
function renderContacts(){ const box=$('#contactList'); box.innerHTML=''; for(const c of store.contacts){ const row=div('contacts contact'); const av=avatarEl(c); av.addEventListener('click',(e)=>{e.stopPropagation(); openProfile(c.id)}); row.appendChild(av); const mid=div(''); mid.innerHTML=`<div class="name">${displayName(c)}</div><div class="meta">${escape(c.sig||'这个人很神秘...')}</div>`; row.appendChild(mid); const btn=div('chip','发消息'); btn.addEventListener('click',(e)=>{e.stopPropagation(); openDM(c.id)}); row.appendChild(btn); row.addEventListener('click',()=>openProfile(c.id)); box.appendChild(row) } }
function renderGroups(){ const box=$('#groupList'); box.innerHTML=''; for(const g of store.chats.filter(c=>c.type==='group')){ const row=div('contacts contact'); row.appendChild(groupAvatar(g)); const mid=div(''); mid.innerHTML=`<div class="name">${g.name}</div><div class="meta">成员：${g.members.length}</div>`; row.appendChild(mid); const btn=div('chip','进入'); btn.addEventListener('click',()=>openChat(g.id)); row.appendChild(btn); box.appendChild(row) } }
function renderMoments(){ const box=$('#moments'); box.innerHTML=''; for(const m of store.moments.slice().reverse()){ const c=m.user==='me'?store.me:contactById(m.user); const card=div('moment'); const head=div('row'); const av=div('avatar small'); fillAvatar(av,c); head.appendChild(av); const meta=div(''); meta.innerHTML=`<div style="font-weight:700">${displayName(c)}</div><div class="small muted">${new Date().toLocaleString()}</div>`; head.appendChild(meta); card.appendChild(head); card.appendChild(div('', escape(m.text))); box.appendChild(card) } }

/* ==== basic dom utils ==== */
function div(cls, txt){ const e=document.createElement('div'); if(cls) e.className=cls; if(txt!=null) e.textContent=txt; return e }
function escape(s=''){return s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function timefmt(t){const d=new Date(t);return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`}
function short(m){ if(m.type==='voice') return `[语音] ${m.sec}″`; return (m.text||'').slice(0,32) }
function displayName(c){ return c.remark && c.remark.trim()? `${c.remark}（${c.name}）` : c.name }
function contactById(id){ return id==='me'?store.me:store.contacts.find(x=>x.id===id) }
function initials(name){return name?.slice(-2)||'?'}
function avatarEl(c){ const d=div('avatar'); fillAvatar(d,c); return d }
function fillAvatar(node,c){ node.innerHTML=''; node.style.background=c.avatarColor||'#8886d8'; if(c.avatarKey){ const img=document.createElement('img'); node.appendChild(img); idbGet(c.avatarKey).then(v=>{ if(v) img.src=v }); }else{ const s=document.createElement('span'); s.className='initials'; s.textContent=initials(displayName(c)); node.appendChild(s) } }
function groupAvatar(g){ const wrap=div('avatar'); wrap.style.background='transparent'; wrap.style.border='1px dashed var(--line)'; wrap.style.display='grid'; wrap.style.gridTemplateColumns='1fr 1fr'; wrap.style.gap='2px'; for(const id of g.members.filter(x=>x!=='me').slice(0,4)){ const s=avatarEl(contactById(id)); s.classList.add('tiny'); s.style.border='1px solid #fff'; wrap.appendChild(s) } return wrap }

/* ==== chat modal ==== */
let currentChatId=null;
function openDM(cid){ let chat=store.chats.find(c=>c.type==='dm'&&c.members.includes(cid)); if(!chat){ chat={id:'dm_'+cid,type:'dm',name:displayName(contactById(cid)),members:['me',cid],messages:[],bgKey:null}; store.chats.unshift(chat); saveState(); renderInbox(); } openChat(chat.id) }
function openChat(id){ currentChatId=id; $('#chatModal').style.display='block'; const chat=store.chats.find(c=>c.id===id); $('#chatTitle').textContent=chat.name; $('#chatSubtitle').textContent = chat.type==='group'?`成员 ${chat.members.length}`: displayName(contactById(chat.members.find(x=>x!=='me'))); renderMsgs(); setTimeout(()=>{ const area=$('#chatArea'); area.scrollTop=area.scrollHeight },30) }
function closeChat(){ $('#chatModal').style.display='none'; currentChatId=null }
function openChatMenu(){ const m=$('#chatMenu'); m.style.display=m.style.display==='block'?'none':'block'; setTimeout(()=>document.addEventListener('click',()=>m.style.display='none',{once:true}),0) }
function clearChat(){ const chat=curr(); chat.messages=[]; saveState(); renderMsgs() }
function curr(){ return store.chats.find(c=>c.id===currentChatId) }

function renderMsgs(){

function bindAvatarGestures(node, contact, chat){
  // double-tap (touch)
  let lastTap=0, pressTimer=null;
  node.addEventListener('touchend', (e)=>{
    const now=Date.now();
    if(now - lastTap < 350){ // double tap
      e.preventDefault();
      sendPat(contact.id, chat);
    }
    lastTap=now;
  }, {passive:true});
  // dblclick (mouse)
  node.addEventListener('dblclick', (e)=>{ e.preventDefault(); sendPat(contact.id, chat); });
  // long press -> @mention
  const start=()=>{ pressTimer=setTimeout(()=>{ insertMention(contact); }, 550) };
  const cancel=()=>{ if(pressTimer){ clearTimeout(pressTimer); pressTimer=null } };
  node.addEventListener('touchstart', start, {passive:true});
  node.addEventListener('touchmove', cancel, {passive:true});
  node.addEventListener('touchend', cancel, {passive:true});
  node.addEventListener('mousedown', start);
  node.addEventListener('mouseleave', cancel);
  node.addEventListener('mouseup', cancel);
}

function insertMention(contact){
  const input=document.getElementById('input');
  const name=displayName(contact);
  const insert='@'+name+' ';
  // append at caret (simple)
  const start=input.selectionStart||input.value.length;
  const end=input.selectionEnd||input.value.length;
  input.value = input.value.slice(0,start) + insert + input.value.slice(end);
  input.focus();
  input.selectionStart=input.selectionEnd=start+insert.length;
}

function sendPat(contactId, chat){
  const target = contactById(contactId);
  const text = `👋 你拍了拍「${displayName(target)}」`;
  chat.messages.push(sys(text));
  saveState(); if(curr()&&curr().id===chat.id){ renderMsgs(); const area=document.getElementById('chatArea'); area.scrollTop=area.scrollHeight }
  // ensure the target responds soon
  setTimeout(()=>botReply(contactId, chat, {text:'（被拍一拍）'}), 1000 + Math.random()*2000);
}
 const box=$('#msgs'); box.innerHTML=''; if(!currentChatId) return; const chat=curr(); let last=0; for(const m of (chat.messages||[])){ if(m.time-last>5*60*1000){ box.appendChild(div('timestamp',new Date(m.time).toLocaleString())); last=m.time } if(m.type==='system'){ const row=div('msg system'); const b=div('bubble',m.text); row.appendChild(b); box.appendChild(row); continue } const mine=m.sender==='me'; const row=div('msg'+(mine?' me':'')); const sender=contactById(m.sender); const av=avatarEl(sender); av.classList.add('small'); bindAvatarGestures(av, sender, chat); const b=div('bubble'); b.innerHTML=escape(m.text||''); if(mine){ row.appendChild(b); row.appendChild(av) } else { row.appendChild(av); row.appendChild(b) } box.appendChild(row) } }

/* ==== input / send ==== */
function onInputChange(e){ /* mention box 可自行添加，这里省略 */ }
function sendMsg(){ const chat=curr(); if(!chat) return; const box=$('#input'); let text=box.value.trim(); if(!text) return; const m=txt('me',text); chat.messages.push(m); saveState(); renderMsgs(); box.value=''; const responders = chat.type==='group' ? chat.members.filter(x=>x!=='me') : [chat.members.find(x=>x!=='me')]; // schedule replies
  const targets = chat.type==='group' ? pickMany(responders, Math.min(3,Math.max(1,Math.round(Math.random()*3)))) : responders;
  for(const id of targets){ const delay=rand(1200,9000); setTimeout(()=>botReply(id, chat, m), delay) }
}
function pickMany(arr,n){ const a=[...arr]; const out=[]; while(a.length&&out.length<n){ out.push(a.splice(Math.floor(Math.random()*a.length),1)[0]) } return out }
function rand(a,b){ return Math.floor(a+Math.random()*(b-a)) }

/* ==== offline brain ==== */
function brainOf(id){ if(!store.brains[id]) store.brains[id]={mood:0,seen:Date.now(),lastSaid:[],facts:[],kv:{}}; return store.brains[id] }
function keywords(s){return (s||'').toLowerCase().split(/[^a-zA-Z0-9\u4e00-\u9fa5]+/).filter(Boolean)}
function scoreByMemory(persona, msg){ const kw=keywords(msg.text).slice(0,12); let score=0; for(const f of (persona.memory||[])){ for(const w of kw){ if(f.includes(w)) score+=1 } } return score }
function templateLines(c,topic){ const name=c.name; const pool={
  '训练':[ '热身别省，今天核心+灵敏。','安排见群公告，别迟到。','训练负荷我会再调。' ],
  '比赛':[ '对手二发偏弱，接发上压。','临场别急，先稳比分。','赛后把数据发我。' ],
  '部活':[ '值日表已更新。','器材领用记得登记。','请按时提交周报。' ],
  '节日':[ '节日快乐，注意休息。','下午有社团联动活动。','礼物先别太贵。' ],
  '八卦':[ '八卦就到此为止。','消息未证实别扩散。','我听说也只是听说。' ],
  '矛盾':[ '有分歧先线下谈。','把事说清楚。','建议冷静十分钟再聊。' ],
  '日常':[ '在看资料。','刚浇了花。','午饭要不要一起？' ]
}; let s=pick(pool[topic]||pool['日常']); if(name==='真田弦一郎'&& !s.includes('遵守纪律')) s+=' 遵守纪律。'; if(name==='柳莲二') s+='（数据稍后给出）'; if(name==='丸井文太') s=s.replace('。','！'); if(name==='仁王雅治') s=pick(['咦？变个把戏看看☆','先来点小戏法，等我～','别被表面骗了喔☆']); return s }
function pick(arr){return arr[Math.floor(Math.random()*arr.length)]}
function decideTopic(text){ const map=[['训练',['训练','热身','跑步','拉伸','体能']],['比赛',['比赛','对阵','得分','发球','接发']],['部活',['部活','社团','安排','周报','器材']],['节日',['节日','礼物','假期','庆祝']],['八卦',['八卦','吃瓜','爆料']],['矛盾',['吵架','矛盾','冲突','生气']]]; const t=text||''; for(const [k,arr] of map){ for(const w of arr){ if(t.includes(w)) return k } } return '日常' }
function obeyStyle(c,line){ const p=c.persona||{}; // 软约束：加入口头禅/禁止项
  if(p.voice && p.voice.includes('温柔')) line=line.replace('。','。');
  if(p.voice && p.voice.includes('活泼')) line += pick(['(｡•̀ᴗ-)✧','♪','✧']);
  return line
}
function composeOffline(c, msg){ const topic=decideTopic(msg.text); let base=templateLines(c, topic); const sc=scoreByMemory(c.persona||{}, msg); if(sc>=2 && c.name==='幸村精市'){ base+=' 我会在。' } return obeyStyle(c, base) }

/* ==== multi-engine: per-contact backend routing ==== */
function currentDefaultEngine(){ const key=store.settings.defaultEngine||'builtin'; return store.settings.engines[key]||{label:'builtin',type:'builtin'} }
function engineOfContact(id){ const c=contactById(id); const key=c.engine||store.settings.defaultEngine||'builtin'; return store.settings.engines[key]||{label:'builtin',type:'builtin'} }

async function botReply(contactId, chat, userMsg){
  const c=contactById(contactId); const engine=engineOfContact(contactId);
  let reply='';
  if(engine.type==='builtin'){
    reply = composeOffline(c, userMsg);
  }else if(engine.type==='openai'){
    try{
      const context = buildPrompt(c, chat, userMsg);
      const rsp = await callProxyLLM(engine.engineId || 'proxy-openai', context);
      reply = (rsp && rsp.text) ? rsp.text.trim() : composeOffline(c, userMsg);
    }catch(e){ reply = composeOffline(c, userMsg) }
  }else{
    reply = composeOffline(c, userMsg);
  }
  chat.messages.push(txt(c.id, reply)); saveState(); if(curr()&&curr().id===chat.id){ renderMsgs(); const area=$('#chatArea'); area.scrollTop=area.scrollHeight }
}

function buildPrompt(c, chat, userMsg){
  const recent = (chat.messages||[]).slice(-20).map(m=>({role:m.sender==='me'?'user':(m.sender==='system'?'system':'assistant'), content:(m.text||'')}));
  const sys=[
    `你扮演《网球王子》的${c.name}（${c.persona?.role||''}）。保持不OOC：${(c.persona?.styleRules||[]).join('；')}`,
    `人物长期记忆（可参考，不要硬背）：${(c.persona?.memory||[]).join('；')}`,
    `回复风格：${c.persona?.voice||''}。避免答非所问，结合最近对话语境作答。`
  ].join('\n');
  return { system:sys, messages:recent };
}

/* ==== proxy call (Netlify Function /api/llm) ==== */
async function callProxyLLM(engineId, context){
  const r = await fetch('/.netlify/functions/llm-proxy',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({engine:engineId, model: currentDefaultEngine().model || 'gpt-4.1-mini', context})
  });
  if(!r.ok) throw new Error('proxy failed');
  return await r.json();
}

/* ==== profile & engines UI ==== */
function openProfile(id){
  const c=id==='me'?store.me:contactById(id); const isMe=(id==='me');
  const engines=store.settings.engines; const keys=Object.keys(engines);
  const options=keys.map(k=>`<option value="${k}" ${c.engine===k?'selected':''}>${engines[k].label}</option>`).join('');
  const body=`
    <div class="row">
      <div class="avatar" id="p_avatar" style="background:${c.avatarColor}"></div>
      <div><div style="font-weight:700">网名：<input id="p_name" value="${c.name}" style="border:1px solid var(--line);border-radius:8px;padding:3px 6px"></div><div class="small muted">ID：${c.id}</div></div>
    </div>
    <div style="margin-top:8px">备注：<input id="p_remark" value="${c.remark||''}" style="width:100%;border:1px solid var(--line);border-radius:8px;padding:6px"></div>
    <div style="margin-top:8px">个性签名：<input id="p_sig" value="${c.sig||''}" style="width:100%;border:1px solid var(--line);border-radius:8px;padding:6px"></div>
    <div style="margin-top:8px">个人状态：<input id="p_stat" value="${c.status||''}" style="width:100%;border:1px solid var(--line);border-radius:8px;padding:6px"></div>
    <div style="margin-top:8px">对话引擎：<select id="p_engine"><option value="">（跟随全局：${currentDefaultEngine().label}）</option>${options}</select></div>
    <div class="row" style="justify-content:space-between;margin-top:10px;flex-wrap:wrap">
      <div class="row">
        <button class="btn" id="p_img">换头像图片</button>
        <button class="btn" id="p_img_clear">清除图片</button>
        <button class="btn" id="p_color">换头像底色</button>
      </div>
      <div class="row" style="margin-left:auto">
        ${!isMe? '<button class="btn" id="p_msg">发消息</button>':''}
        ${!isMe? '<button class="btn" id="p_del">删除好友</button>':''}
        <button class="btn" id="p_ok">保存</button>
      </div>
    </div>`;
  openSheet('资料卡', body, (dom)=>{
    const av=dom.querySelector('#p_avatar'); fillAvatar(av,c);
    dom.querySelector('#p_ok').addEventListener('click',()=>{ c.name=dom.querySelector('#p_name').value; c.remark=dom.querySelector('#p_remark').value; c.sig=dom.querySelector('#p_sig').value; c.status=dom.querySelector('#p_stat').value; c.engine=dom.querySelector('#p_engine').value||null; saveState(); closeSheet(); renderAll(); })
    dom.querySelector('#p_color').addEventListener('click',()=>{ c.avatarColor=randomPastel(); saveState(); openProfile(id) })
    dom.querySelector('#p_img').addEventListener('click',()=>{ pickImage((data)=>{ const key='av_'+c.id; idbPut(key,data).then(()=>{ c.avatarKey=key; saveState(); openProfile(id); renderAll(); }) }) })
    dom.querySelector('#p_img_clear').addEventListener('click',()=>{ if(c.avatarKey) idbDel(c.avatarKey); c.avatarKey=null; saveState(); openProfile(id); renderAll(); })
    if(!isMe){ dom.querySelector('#p_msg').addEventListener('click',()=>{ closeSheet(); openDM(c.id) }); dom.querySelector('#p_del').addEventListener('click',()=>{ if(confirm('删除该好友及相关单聊？')){ store.contacts=store.contacts.filter(x=>x.id!==id); store.chats=store.chats.filter(ch=>!(ch.type==='dm'&&ch.members.includes(id))); saveState(); closeSheet(); renderAll(); } }) }
  })
}

function openEngineManager(){
  const keys=Object.keys(store.settings.engines);
  const rows = keys.map(k=>{
    const e=store.settings.engines[k];
    const info = e.type==='builtin' ? '离线人格' : `代理(${e.type}) 模型: ${e.model||'-'}`;
    return `<div style="border:1px solid var(--line);border-radius:10px;padding:8px;margin:6px 0"><div class="row" style="justify-content:space-between"><div><b>${e.label}</b><div class="small muted">${info}</div></div><button class="btn" data-edit="${k}">配置</button></div></div>`
  }).join('');
  const body = `<div class="content">
    ${rows}
    <div class="row" style="justify-content:flex-end"><button class="btn" id="add">+ 新增引擎</button></div>
    <div class="small muted">说明：代理模式会请求 <code>/.netlify/functions/llm-proxy</code>，秘钥放在 Netlify 环境变量里更安全。</div>
  </div>`;
  openSheet('引擎管理', body, (dom)=>{
    dom.querySelectorAll('[data-edit]').forEach(btn=> btn.addEventListener('click',()=> editEngine(btn.getAttribute('data-edit')) ));
    dom.querySelector('#add').addEventListener('click',()=> editEngine(null));
  })
}
function editEngine(key){
  const e = key? store.settings.engines[key] : {label:'新引擎',type:'openai',viaProxy:true,model:'gpt-4o-mini',engineId:'proxy-custom'};
  const body=`<div class="grid">
    <label>显示名称<input id="e_label" class="btn" value="${e.label||''}"></label>
    <label>类型<select id="e_type" class="btn"><option value="openai" ${e.type==='openai'?'selected':''}>OpenAI 兼容</option><option value="builtin" ${e.type==='builtin'?'selected':''}>离线人格</option></select></label>
    <label>模型<input id="e_model" class="btn" value="${e.model||''}" placeholder="gpt-4o-mini / qwen2.5 / deepseek-chat ..."></label>
    <label>通过代理<select id="e_via" class="btn"><option value="1" ${e.viaProxy?'selected':''}>是（推荐）</option><option value="0" ${!e.viaProxy?'selected':''}>否（直接请求，风险）</option></select></label>
    <label>引擎ID（代理用）<input id="e_id" class="btn" value="${e.engineId||''}" placeholder="proxy-openai / proxy-qwen ..."></label>
    <label>直连 BaseURL（非代理用）<input id="e_base" class="btn" value="${e.baseUrl||''}" placeholder="https://api.example.com/v1"></label>
    <label>直连 API Key（非代理用）<input id="e_key" class="btn" value="${e.apiKey||''}" placeholder="仅用于直连，别放真实密钥"></label>
  </div>
  <div class="row" style="justify-content:flex-end;margin-top:8px"><button class="btn" id="ok">保存</button></div>`;
  openSheet('编辑引擎', body, (dom)=>{
    dom.querySelector('#ok').addEventListener('click',()=>{
      const obj={label:$('#e_label').value,type:$('#e_type').value,model:$('#e_model').value,viaProxy:$('#e_via').value==='1',engineId:$('#e_id').value,baseUrl:$('#e_base').value,apiKey:$('#e_key').value};
      if(key) store.settings.engines[key]=obj; else { const nk='engine_'+rid(); store.settings.engines[nk]=obj }
      saveState(); closeSheet(); openEngineManager(); renderAll();
    })
  })
}
function switchDefaultEngine(){
  const keys=Object.keys(store.settings.engines); const curr=store.settings.defaultEngine||'builtin'; const idx=Math.max(0, keys.indexOf(curr)); const next=keys[(idx+1)%keys.length]; store.settings.defaultEngine=next; saveState(); renderAll();
}

/* ==== file utils ==== */
function pickImage(cb){ const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; inp.onchange=()=>{ const f=inp.files[0]; const r=new FileReader(); r.onload=()=>{ compress(r.result,128,0.8).then(d=>cb(d)).catch(()=>cb(r.result)) }; r.readAsDataURL(f) }; inp.click() }
function compress(src,maxSide=128,q=0.8){ return new Promise((res,rej)=>{ const img=new Image(); img.onload=()=>{ const s=Math.min(1,maxSide/Math.max(img.width,img.height)); const w=Math.round(img.width*s),h=Math.round(img.height*s); const canvas=document.createElement('canvas'); canvas.width=w; canvas.height=h; const ctx=canvas.getContext('2d'); ctx.drawImage(img,0,0,w,h); res(canvas.toDataURL('image/webp',q)); }; img.onerror=rej; img.src=src }) }

/* ==== sheet / helper ==== */
function openSheet(title, html, onready){ const s=$('#sheet'); $('#sheetTitle').textContent=title; $('#sheetBody').innerHTML=html; s.classList.remove('hidden'); if(onready) onready($('#sheetBody')) }
function closeSheet(){ $('#sheet').classList.add('hidden') }
function randomPastel(){ const h=Math.floor(Math.random()*360); return `hsl(${h} 70% 70%)` }

/* ==== top "+" actions ==== */
function openGroupCreator(){ const body=`<div>选择成员：</div><div class="sheet grid" style="max-height:260px;overflow:auto">${store.contacts.map(c=>`<label style="display:flex;gap:8px;align-items:center;border:1px solid var(--line);border-radius:10px;padding:6px"><input type="checkbox" name="mem" value="${c.id}"/> <span class="avatar tiny" style="background:${c.avatarColor}"><span class="initials">${initials(displayName(c))}</span></span> ${displayName(c)}</label>`).join('')}</div><div style="margin-top:8px">群名：<input id="g_name" value="新的群聊" class="btn" style="width:100%"></div><div style="text-align:right;margin-top:8px"><button class="btn" id="g_ok">创建</button></div>`; openSheet('发起群聊', body, (dom)=>{ dom.querySelector('#g_ok').addEventListener('click',()=>{ const mem=[...dom.querySelectorAll('input[name=mem]:checked')].map(i=>i.value); if(!mem.length){ alert('至少选择一位'); return } const name=$('#g_name').value||'新的群聊'; const chat={id:'grp_'+rid(),type:'group',name,members:['me',...mem],messages:[sys('群聊已创建')],bgKey:null}; store.chats.unshift(chat); saveState(); closeSheet(); renderInbox(); openChat(chat.id) }) }) }
function openAddFriend(){ const body=`<div class="sheet grid"><input id="f_name" class="btn" placeholder="网名"><input id="f_sig" class="btn" placeholder="个性签名"><input id="f_id" class="btn" placeholder="自定义ID（可留空自动）"><button class="btn" id="f_color">随机头像色</button><button class="btn" id="f_img">上传头像图片</button></div><div style="text-align:right;margin-top:8px"><button class="btn" id="f_ok">添加</button></div>`; openSheet('添加好友', body, (dom)=>{ let color=randomPastel(); let data=null; dom.querySelector('#f_color').style.background=color; dom.querySelector('#f_color').addEventListener('click',()=>{color=randomPastel(); dom.querySelector('#f_color').style.background=color}); dom.querySelector('#f_img').addEventListener('click',()=>pickImage(d=>{data=d; dom.querySelector('#f_img').textContent='已选择图片'})); dom.querySelector('#f_ok').addEventListener('click',()=>{ const id=$('#f_id').value.trim()||('u_'+rid()); const name=$('#f_name').value.trim()||('新朋友'+id.slice(-3)); const sig=$('#f_sig').value.trim(); const newc={id,name,sig,remark:'',status:'',avatarColor:color,avatarKey:null,persona:{role:'新朋友',voice:'普通',styleRules:['友好简洁'],memory:[]},engine:null}; store.contacts.push(newc); if(data){ idbPut('av_'+id,data).then(()=>{ newc.avatarKey='av_'+id; saveState(); renderContacts(); closeSheet(); }) } else { saveState(); renderContacts(); closeSheet(); } }) }) }

/* ==== background & data ==== */
function pickBg(){ const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; inp.onchange=()=>{ const f=inp.files[0]; const r=new FileReader(); r.onload=()=>{ compress(r.result,960,0.8).then(d=> idbPut('bg_global',d).then(()=>{ store.settings.bgKey='bg_global'; saveState(); if(curr()) idbGet('bg_global').then(x=> $('#chatArea').style.backgroundImage=`url(${x})`) })) }; r.readAsDataURL(f) }; inp.click() }
function clearBg(){ store.settings.bgKey=null; saveState(); if(curr()) $('#chatArea').style.backgroundImage='none' }
function exportData(){ const blob=new Blob([JSON.stringify(store,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='rikkai_data.json'; a.click() }
function importData(){ const inp=document.createElement('input'); inp.type='file'; inp.accept='application/json'; inp.onchange=()=>{ const f=inp.files[0]; const r=new FileReader(); r.onload=()=>{ try{ store=JSON.parse(r.result); saveState(); renderAll(); alert('导入成功'); }catch(e){ alert('导入失败：'+e.message) } }; r.readAsText(f) }; inp.click() }
function resetAll(){ if(confirm('重置并清空所有本地数据（不包含已缓存的图片）？')){ localStorage.removeItem(STATE_KEY); location.reload() } }
async function updateUsage(){ if(navigator.storage && navigator.storage.estimate){ const est=await navigator.storage.estimate(); const u=est.usage||0,q=est.quota||1; $('#usageLine').textContent=`本地用量：${(u/1024/1024).toFixed(2)}MB / ${(q/1024/1024).toFixed(0)}MB` } else $('#usageLine').textContent='本地用量：浏览器未提供统计' }

/* ==== misc ==== */
function seedMoments(){ const seed=[{user:'yukimura',text:'微风适宜，今天也会赢。'},{user:'sanada',text:'风林火山。'},{user:'yanagi',text:'数据更新：第一发进球率+3%。'},{user:'marui',text:'泡芙真的治愈一切(˶˃ ᵕ ˂˶)'},{user:'akaya',text:'我要更强！给我安排！'},{user:'niou',text:'戏法开始前，先安静～'},{user:'sakura',text:'女网招新海报出炉啦♪'},{user:'yamada',text:'力量组记得拉伸。'}]; store.moments.push(...seed); saveState() }
async function migrateBlobs(){ let changed=false; if(store.me.avatarUrl&&!store.me.avatarKey){await idbPut('av_me',store.me.avatarUrl); store.me.avatarKey='av_me'; store.me.avatarUrl=''; changed=true} for(const c of store.contacts){ if(c.avatarUrl&&!c.avatarKey){ await idbPut('av_'+c.id,c.avatarUrl); c.avatarKey='av_'+c.id; c.avatarUrl=''; changed=true } } if(store.settings.bg&&!store.settings.bgKey){ await idbPut('bg_global',store.settings.bg); store.settings.bgKey='bg_global'; store.settings.bg=''; changed=true } for(const ch of store.chats){ if(ch.bg&&!ch.bgKey){ await idbPut('bg_'+ch.id,ch.bg); ch.bgKey='bg_'+ch.id; ch.bg=''; changed=true } } if(changed) saveState() }

document.getElementById("btnSend")?.addEventListener("click", sendMsg);
document.getElementById("btnEmoji")?.addEventListener("click", ()=>{ try{ insertEmoji && insertEmoji("😊") }catch(e){} });

/* mention-priority */
(()=>{
  function beforeText(){ const el=document.getElementById('input'); return el? el.value.trim():'' }
  const alias={yukimura:['幸村精市','幸村','精市','部长'],sanada:['真田弦一郎','真田','一郎','副部长'],yanagi:['柳莲二','柳','莲二'],marui:['丸井文太','丸井','文太'],akaya:['切原赤也','切原','赤也'],kawamura:['胡狼桑原','桑原','胡狼'],yanagi_b:['柳生比吕士','柳生','比吕士'],niou:['仁王雅治','仁王','雅治'],sakura:['樱井幸','樱井','小幸','幸'],yamada:['山田玲英','山田','玲英'],};
  function resolveMentions(t){const at=new Set();const tokens=Array.from(new Set((t.match(/@?([^\s@，。]+)/g)||[]).map(s=>s.replace(/^@/,''))));for(const [id,names] of Object.entries(alias)){if(tokens.some(x=>names.includes(x))) at.add(id); if(names.some(n=>t.includes('@'+n))) at.add(id);} return Array.from(at);}
  const _sendMsg=window.sendMsg;
  window.sendMsg=function(){ const text=beforeText(); _sendMsg(); const chat=curr&&curr(); if(!chat) return; const mentions=resolveMentions(text); if(mentions.length){ let d=600; mentions.forEach(id=>setTimeout(()=>botReply(id,chat,{text}),d)); } };
})();


/* ====== DM header (avatar + names) & Discover Likes Patch ====== */
(function(){
  // Helpers expected in app: curr(), getContact(id), avatarUrl(c), openProfile(id)
  function ensureTopbarPeer(){
    try{
      const chat = (typeof curr === 'function') ? curr() : null;
      if(!chat || chat.type !== 'dm') return;

      // Find title container
      const top = document.querySelector('.topbar .titlewrap, .topbar .title, .topbar .name');
      if(!top) return;

      // If already rendered for this peer, skip
      if(top.dataset.peerId === chat.peerId && top.querySelector('.peer')) return;

      const c = (typeof getContact==='function') ? getContact(chat.peerId) : chat.peer || {name:chat.name};
      const name = (c && (c.remark && c.remark.trim())) || (c && c.name) || chat.name || '';
      const sub  = (c && c.sig) || '';
      const ava  = (typeof avatarUrl==='function') ? avatarUrl(c) : (c && c.avatarUrl) || '';

      top.dataset.peerId = chat.peerId || '';
      top.innerHTML = [
        '<div class="peer">',
          '<img class="ava" src="'+ (ava||'') +'" alt="'+ name.replace(/"/g,'&quot;') +'" onerror="this.style.background=\'#eaeaea\'"/>',
          '<div class="names">',
            '<div class="title">'+ name +'</div>',
            '<div class="sub">'+ (sub||'') +'</div>',
          '</div>',
        '</div>'
      ].join('');

      top.querySelector('.ava')?.addEventListener('click', ()=>{
        try{ openProfile && openProfile(chat.peerId); }catch(e){}
      });
    }catch(e){ /* silent */ }
  }

  // Run on load and when topbar changes
  const topbar = document.querySelector('.topbar');
  if(topbar){
    const mo = new MutationObserver(()=> setTimeout(ensureTopbarPeer,0));
    mo.observe(topbar, {childList:true, subtree:true});
  }
  document.addEventListener('DOMContentLoaded', ensureTopbarPeer);
  window.addEventListener('hashchange', ()=> setTimeout(ensureTopbarPeer, 50));
  setTimeout(ensureTopbarPeer, 100);

  // ===== Discover Likes =====
  const LS_LIKES   = 'status_likes';
  const LS_MYLIKES = 'status_myLikes';
  let likes   = new Map(Object.entries(JSON.parse(localStorage.getItem(LS_LIKES)||'{}')).map(([k,v])=>[k,Number(v)]));
  let myLikes = new Set(JSON.parse(localStorage.getItem(LS_MYLIKES)||'[]'));

  function saveLikes(){
    localStorage.setItem(LS_LIKES,   JSON.stringify(Object.fromEntries(likes)));
    localStorage.setItem(LS_MYLIKES, JSON.stringify(Array.from(myLikes)));
  }

  function enhanceDiscover(){
    // Try common containers
    const root = document.querySelector('.discover, #discover, [data-page="discover"]') || document;
    // Cards: be permissive
    const cards = root.querySelectorAll('.status, .card, .feed-item, .moment, .discover-item');
    let idx = 0;
    cards.forEach((card)=>{
      // skip if already has likebar
      if(card.querySelector('.status-likebar')) return;
      // assign id
      const id = card.dataset.id || ('auto_'+(idx++));
      card.dataset.id = id;
      // read current count
      const count = likes.get(id) || 0;
      const liked = myLikes.has(id);
      // append likebar at tail
      const bar = document.createElement('div');
      bar.className = 'status-likebar';
      bar.innerHTML = '<button class="like '+(liked?'on':'')+'" data-id="'+id+'"><span class="heart">❤</span><span class="count">'+count+'</span></button>';
      card.appendChild(bar);
    });
  }

  function toggleLike(id){
    const liked = myLikes.has(id);
    if(liked){
      myLikes.delete(id);
      likes.set(id, Math.max(0,(likes.get(id)||0)-1));
    }else{
      myLikes.add(id);
      likes.set(id, (likes.get(id)||0)+1);
    }
    saveLikes();
    // update UI
    document.querySelectorAll('.status-likebar .like[data-id="'+id+'"]').forEach(btn=>{
      btn.classList.toggle('on', !liked);
      const cnt = btn.querySelector('.count');
      if(cnt) cnt.textContent = likes.get(id) || 0;
    });
  }

  // Event delegation
  document.addEventListener('click', (e)=>{
    const btn = e.target.closest('.status-likebar .like');
    if(btn){ toggleLike(btn.dataset.id); }
  }, true);

  // Run enhance when discover tab shows (hashchange or tab click)
  function maybeEnhanceDiscover(){ setTimeout(enhanceDiscover,60); try{ if(window._discoverLikeInterval) clearInterval(window._discoverLikeInterval); window._discoverLikeInterval=setInterval(function(){ if(document.querySelector('#discover')){ try{ enhanceDiscover(); }catch(e){} } }, 3000);}catch(e){} }
  window.addEventListener('hashchange', maybeEnhanceDiscover);
  document.addEventListener('DOMContentLoaded', maybeEnhanceDiscover);
  setTimeout(maybeEnhanceDiscover, 200);
})();


/* ---- peer overlay + cleanup sendbars ---- */
(function(){
  function cleanupSendBars(){
    document.querySelectorAll('.sendbar,.big-send,.sticky-send,.footer-send,#sendbar,#quickSend,#primarySend')
      .forEach(el=>{ try{ el.style.display='none'/*safe-hide*/; }catch(e){} });
  }
  document.addEventListener('DOMContentLoaded', cleanupSendBars);
  setTimeout(cleanupSendBars, 200);
  window.addEventListener('hashchange', ()=>setTimeout(cleanupSendBars, 60));

  function mountPeer(){
    try{
      const chat = (typeof curr==='function')? curr(): null;
      if(!chat || chat.type!=='dm') return;
      const tb = document.querySelector('.topbar'); if(!tb) return;
      tb.classList.add('has-peer');

      let wrap = tb.querySelector('.peer-fixed');
      if(!wrap){
        wrap = document.createElement('div');
        wrap.className = 'peer-fixed';
        tb.appendChild(wrap);
      }
      const c = (typeof getContact==='function') ? getContact(chat.peerId) : chat.peer || {name:chat.name};
      const name = (c && (c.remark && c.remark.trim())) || (c && c.name) || chat.name || '';
      const sub  = (c && c.sig) || '';
      const ava  = (typeof avatarUrl==='function') ? avatarUrl(c) : (c && c.avatarUrl) || '';

      wrap.innerHTML = '<img class="ava" src="'+(ava||'')+'" alt="'+name.replace(/"/g,'&quot;')+'"/>' +
                       '<div class="names"><div class="title">'+name+'</div><div class="sub">'+(sub||'')+'</div></div>';
      wrap.querySelector('.ava')?.addEventListener('click', ()=>{ try{ openProfile && openProfile(chat.peerId); }catch(e){} });
    }catch(e){}
  }
  document.addEventListener('DOMContentLoaded', ()=>setTimeout(mountPeer,60));
  window.addEventListener('hashchange', ()=>setTimeout(mountPeer,60));
  setInterval(mountPeer, 1200); // keep it robust during transitions
})();


/* ===== Ultra robust header+sendbar sanitizer ===== */
(function(){
  // Remove giant fixed-bottom "发送" bars heuristically
  function nukeGiantSendBars(){
    const candidates = Array.from(document.querySelectorAll('button,.btn,.weui-btn,.primary,.footer button'));
    const viewportH = window.innerHeight || 800;
    candidates.forEach(el=>{
      try{
        const txt = (el.textContent||'').trim();
        if(!txt) return;
        if(!/^(发送|Send)$/i.test(txt)) return;
        const r = el.getBoundingClientRect();
        const isGiant = r.width>180 && r.height>40;
        const nearBottom = (viewportH - r.bottom) < 140; // close to bottom
        if(isGiant && nearBottom){
          // remove whole bar container if it only contains this button
          const bar = el.closest('.footer,.sendbar,.big-send,.sticky-send,.footer-send') || el.parentElement;
          (bar||el).style.display='none';
          (bar||el).remove?.();
        }
      }catch(e){}
    });
  }

  // Ensure overlay peer appears and hide default titles (including bare text nodes)
  function mountPeerOverlay(){
    try{
      if(typeof curr!=='function') return;
      const chat = curr();
      if(!chat || chat.type!=='dm') return;
      const tb = document.querySelector('.topbar');
      if(!tb) return;
      tb.classList.add('has-peer');

      // Hide any bare text nodes in topbar title area
      Array.from(tb.childNodes).forEach(n=>{
        if(n.nodeType===3 && n.textContent.trim()){
          n.textContent='';
        }
      });

      let wrap = tb.querySelector('.peer-fixed');
      if(!wrap){
        wrap = document.createElement('div');
        wrap.className = 'peer-fixed';
        tb.appendChild(wrap);
      }

      const c = (typeof getContact==='function') ? getContact(chat.peerId) : chat.peer || {name:chat.name};
      const name = (c && (c.remark && c.remark.trim())) || (c && c.name) || chat.name || '';
      const sub  = (c && c.sig) || '';
      const ava  = (typeof avatarUrl==='function') ? avatarUrl(c) : (c && c.avatarUrl) || '';

      wrap.innerHTML = '<img class="ava" src="'+(ava||'')+'" alt="'+name.replace(/"/g,'&quot;')+'"/>' +
                       '<div class="names"><div class="title">'+name+'</div><div class="sub">'+(sub||'')+'</div></div>';
      wrap.querySelector('.ava')?.addEventListener('click', ()=>{ try{ openProfile && openProfile(chat.peerId); }catch(e){} });
    }catch(e){}
  }

  // Observe DOM changes to re-apply both fixes
  const mo = new MutationObserver(()=>{ setTimeout(nukeGiantSendBars,0); setTimeout(mountPeerOverlay,0); });
  mo.observe(document.documentElement, {childList:true, subtree:true});
  window.addEventListener('resize', nukeGiantSendBars);
  document.addEventListener('DOMContentLoaded', ()=>{ nukeGiantSendBars(); mountPeerOverlay(); });
  setTimeout(()=>{ nukeGiantSendBars(); mountPeerOverlay(); }, 200);
  window.addEventListener('hashchange', ()=>{ setTimeout(nukeGiantSendBars,60); setTimeout(mountPeerOverlay,60); });
})();


/* FIX4: Robust duplicate-title dedupe + bottom-sendbar killer */
(function(){
  function rmGiantBars(){
    const vh = window.innerHeight || document.documentElement.clientHeight || 800;
    const nodes = Array.from(document.querySelectorAll('button,.btn,[class*=\"btn\"],footer,[class*=\"send\"],[id*=\"send\"],.footer'));
    nodes.forEach(el=>{
      try{
        const text = (el.textContent||'').trim();
        const rect = el.getBoundingClientRect();
        const nearBottom = (vh - rect.top) < 180 || (vh - rect.bottom) < 120;
        const sizeBig = rect.height > 45 || rect.width > 200;
        const style = getComputedStyle(el);
        const fixed = style.position === 'fixed' || style.position==='sticky';
        const looksSend = /^(发送|Send|發送)$/i.test(text) || /发送/.test((el.innerText||''));
        if((nearBottom && (sizeBig || fixed) && looksSend) || (fixed && nearBottom && /发送/.test(el.innerText||''))){
          let bar = el.closest('.sendbar,.big-send,.sticky-send,.footer-send') || el;
          bar.style.display = 'none';
          bar.remove?.();
        }
      }catch(e){}
    });
  }

  function dedupeTopbar(){
    const tb = document.querySelector('.topbar, .header, .appbar');
    if(!tb) return;

    // hide duplicate leaf texts that repeat exactly
    const map = {};
    Array.from(tb.querySelectorAll('*')).forEach(n=>{
      if(n.children.length===0){
        const t = (n.textContent||'').trim();
        if(t){
          if(map[t]){ n.style.display='none'; }
          else { map[t]=n; }
        }
      }
    });

    // mount peer overlay if we can find contact
    try{
      if(!tb.querySelector('.peer-fixed')){
        let name='', sig='', ava='', pid=null;
        if(typeof curr==='function'){
          const chat = curr();
          if(chat){
            pid = chat.peerId || null;
            if(typeof getContact==='function' && pid!=null){
              const c = getContact(pid) || {};
              name = (c.remark && c.remark.trim()) || c.name || chat.name || '';
              sig  = c.sig || '';
              if(typeof avatarUrl==='function') ava = avatarUrl(c)||'';
              else ava = c.avatarUrl||'';
            }else{
              name = chat.name || '';
            }
          }
        }
        if(name){
          tb.classList.add('has-peer');
          const wrap = document.createElement('div');
          wrap.className = 'peer-fixed';
          wrap.innerHTML = '<img class=\"ava\" alt=\"\"/>' +
                           '<div class=\"names\"><div class=\"title\"></div><div class=\"sub\"></div></div>';
          tb.appendChild(wrap);
          wrap.querySelector('.ava').src = ava||'';
          wrap.querySelector('.title').textContent = name;
          wrap.querySelector('.sub').textContent = sig||'';
          wrap.querySelector('.ava').addEventListener('click', ()=>{ try{ openProfile && openProfile(pid); }catch(e){} });
        }
      }
    }catch(e){}
  }

  const mo = new MutationObserver(()=>{ rmGiantBars(); dedupeTopbar(); });
  mo.observe(document.documentElement, {childList:true, subtree:true});
  window.addEventListener('resize', rmGiantBars);
  window.addEventListener('hashchange', ()=>{ setTimeout(rmGiantBars, 60); setTimeout(dedupeTopbar, 60); });
  document.addEventListener('DOMContentLoaded', ()=>{ rmGiantBars(); dedupeTopbar(); });
  setTimeout(()=>{ rmGiantBars(); dedupeTopbar(); }, 300);
})();

// === DM header avatar + duplicate inputbar guard ===
(function(){
  function genAvatar(name){
    var ch = (name||'?').trim().slice(0,1);
    // pleasant pastel
    var colors=['#8ab4f8','#81c995','#f28b82','#fdd663','#c58af9','#7bdff6','#f19cbb'];
    var bg=colors[Math.abs((ch.charCodeAt(0)||65))%colors.length];
    var svg = "<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64'><rect width='100%' height='100%' rx='32' fill='"+bg+"'/><text x='50%' y='58%' text-anchor='middle' font-size='36' fill='white' font-family='Arial'>"+ch+"</text></svg>";
    return 'data:image/svg+xml;utf8,'+encodeURIComponent(svg);
  }
  function ensureDMHeader(){
    var head=document.querySelector('.chat-head');
    if(!head) return;
    var titleEl=document.getElementById('chatTitle');
    var subEl=document.getElementById('chatSubtitle');
    if(!titleEl||!subEl) return;
    var title=titleEl.textContent||'';
    var subtitle=subEl.textContent||'';
    var isDM = !subtitle || subtitle.trim()===title.trim() || !/成员\s*\d+/.test(subtitle);
    var av=document.getElementById('chatAvatar');
    if(!av){
      av=document.createElement('img');
      av.id='chatAvatar';
      av.className='chat-avatar';
      var titleWrap=document.querySelector('.chat-title-wrap');
      if(titleWrap){ head.insertBefore(av, titleWrap); }
    }
    if(isDM){
      subEl.textContent='';
      av.src = genAvatar(title);
      av.style.display='block';
    }else{
      av.style.display='none';
    }
  }
  function killDupInputs(){
    var bars=[].slice.call(document.querySelectorAll('.inputbar'));
    bars.forEach(function(el,i){ if(i>0){ el.parentNode && el.parentNode.removeChild(el);} });
  }
  // Observe DOM changes to keep things tidy
  var mo = new MutationObserver(function(){ killDupInputs(); ensureDMHeader(); });
  mo.observe(document.body,{childList:true,subtree:true});
  // Also run on key UI events
  document.addEventListener('click', function(){ setTimeout(function(){ killDupInputs(); ensureDMHeader(); }, 0);}, true);
  window.addEventListener('hashchange', function(){ setTimeout(function(){ killDupInputs(); ensureDMHeader(); }, 0);});
  document.addEventListener('DOMContentLoaded', function(){ killDupInputs(); ensureDMHeader(); });
  // small kick on load
  setTimeout(function(){ killDupInputs(); ensureDMHeader(); }, 50);
})();


// === Rikkai hard guard: dedupe composers, enable Me edit, engine drawer close ===
(function(){
  function dedupe(){
    try{
      var bars = Array.from(document.querySelectorAll('.inputbar,[data-role="composer"],.composer'));
      if(bars.length>1){
        // keep the one that has an input or textarea (prefer last)
        var keep = bars.reverse().find(b=>b.querySelector('input,textarea')) || bars[0];
        bars.reverse().forEach(function(b){
          if(b!==keep){ b.remove(); }
        });
      }
      // remove ghost hint-only blocks near bottom
      var hintRe = /发消息.*支持@.*(删除|撤回)/;
      Array.from(document.querySelectorAll('div,section,footer')).forEach(function(n){
        var txt=(n.textContent||'').trim();
        if(hintRe.test(txt) && !n.querySelector('input,textarea,button')){
          var r=n.getBoundingClientRect();
          if(r.bottom > (innerHeight-120)) n.remove();
        }
      });
    }catch(e){}
  }
  function bindMeEdit(){
    document.addEventListener('click', function(e){
      var btn = e.target.closest('button,.btn,[role="button"],a,.chip');
      if(!btn) return;
      var t = (btn.textContent||'').trim();
      if(t==='编辑' && !btn.closest('#engine-drawer,.engine-drawer,[data-panel="engine-manager"],.engine-sheet,.drawer.engine,[data-section="engine"],.engine-item,.engine-card')){
        e.preventDefault();
        var panel = document.querySelector('#me-editor,.me-editor,[data-panel="me-editor"],.profile-editor');
        if(panel){
          panel.style.display='block'; panel.classList.add('open');
          if(!panel.querySelector('.hotfix-close')){
            var x=document.createElement('button'); x.className='hotfix-close'; x.textContent='关闭';
            x.style.cssText='position:absolute;right:12px;top:12px;z-index:100';
            x.onclick=function(){ panel.classList.remove('open'); panel.style.display='none'; };
            panel.appendChild(x);
          }
        }
      }
    }, true);
  }
  function bindEngineClose(){
    var closeAll=function(){
      document.querySelectorAll('#engine-drawer,.engine-drawer,[data-panel="engine-manager"],.engine-sheet,.drawer.engine').forEach(function(d){
        d.style.display='none'; d.classList.remove('open');
      });
    };
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeAll(); });
    new MutationObserver(function(){
      document.querySelectorAll('#engine-drawer,.engine-drawer,[data-panel="engine-manager"],.engine-sheet,.drawer.engine').forEach(function(d){
        if(d.dataset.bound) return;
        d.dataset.bound='1';
        var overlay = d.querySelector('.overlay,.mask,.backdrop');
        if(!overlay){ overlay=document.createElement('div'); overlay.className='overlay'; overlay.style.cssText='position:absolute;inset:0;background:rgba(0,0,0,0.01)'; d.insertBefore(overlay, d.firstChild); }
        overlay.addEventListener('click', closeAll);
        var c = d.querySelector('.close,[data-close],.btn-close');
        if(c) c.addEventListener('click', closeAll);
      });
    }).observe(document.body,{childList:true,subtree:true});
  }
  document.addEventListener('DOMContentLoaded', function(){ dedupe(); bindMeEdit(); bindEngineClose(); });
  // re-run on route changes
  setInterval(dedupe, 1000);
})();



// ==== Rikkai Guard v2: dedupe inputbars, enable Me edit, engine drawer close ====
(function(){
  function $$all(sel, root){ try{ return Array.from((root||document).querySelectorAll(sel)); }catch(e){ return []; } }
  function isVisible(el){ if(!el) return false; const r=el.getBoundingClientRect(); return r.width>0 && r.height>0; }
  function bottomDistance(el){ const r=el.getBoundingClientRect(); return window.innerHeight - r.bottom; }

  function dedupeBars(){
    try{
      // Remove hint-only boxes at screen bottom (no input/button inside)
      const hintRe = /发消息.*支持@.*(删除|撤回)/;
      $$all("div,section,footer").forEach(n=>{
        const txt=(n.textContent||'').replace(/\s+/g,'').trim();
        if(hintRe.test(txt) && !n.querySelector('input,textarea,button')){
          if(bottomDistance(n) < 220){ n.remove(); }
        }
      });
      // Keep only one input bar (prefer the bottom-most that has input/textarea or SEND button)
      const bars = $$all('.inputbar, .composer, .chat-footer, footer .inputbar, footer .composer, .sendbar')
                   .filter(isVisible);
      if(bars.length>1){
        let keep = null, best = -1e9;
        for(const b of bars){
          const ok = b.querySelector('input,textarea,button,[role="textbox"]');
          const dist = -bottomDistance(b); // larger (closer to bottom) preferred
          if(ok && dist > best){ best = dist; keep = b; }
        }
        if(!keep) keep = bars[bars.length-1];
        for(const b of bars){ if(b!==keep) b.remove(); }
      }
      // Make sure bar is sticky & above tabbar
      const bar = $$all('.inputbar').pop();
      if(bar){
        bar.style.position='sticky'; bar.style.bottom='0'; bar.style.zIndex='60';
      }
    }catch(e){}
  }

  function enableMeEdit(){
    document.addEventListener('click', function(e){
      const btn = e.target.closest('button,.btn,[role="button"],a,.chip');
      if(!btn) return;
      const txt = (btn.textContent||'').trim();
      if(txt==='编辑'){
        e.preventDefault();
        // Try find an existing editor panel
        const panel = document.querySelector('#me-editor, .me-editor, [data-panel="me-editor"], .profile-editor, dialog.me');
        if(panel){
          panel.style.display='block'; panel.classList.add('open'); panel.removeAttribute('aria-hidden');
          // add close fallback
          if(!panel.querySelector('.hotfix-close')){
            const x = document.createElement('button');
            x.className='hotfix-close'; x.textContent='关闭';
            x.style.cssText='position:absolute;right:12px;top:12px;z-index:100;border:0;background:#6b63ff;color:#fff;padding:6px 10px;border-radius:10px';
            x.onclick=()=>{ panel.classList.remove('open'); panel.style.display='none'; panel.setAttribute('aria-hidden','true'); };
            panel.appendChild(x);
          }
        }
      }
    }, true);
  }

  function makeEngineClosable(){
    function closeAll(){
      $$all('#engine-drawer, .engine-drawer, [data-panel="engine-manager"], .engine-sheet, .drawer.engine, .engine-drawer-sheet')
        .forEach(d=>{ d.style.display='none'; d.classList.remove('open'); });
    }
    document.addEventListener('keydown', e=>{ if(e.key==='Escape') closeAll(); });
    new MutationObserver(()=>{
      $$all('#engine-drawer, .engine-drawer, [data-panel="engine-manager"], .engine-sheet, .drawer.engine, .engine-drawer-sheet')
        .forEach(d=>{
          if(d.dataset.rkBound) return; d.dataset.rkBound='1';
          let ov = d.querySelector('.overlay,.mask,.backdrop'); 
          if(!ov){ ov=document.createElement('div'); ov.className='overlay'; ov.style.cssText='position:absolute;inset:0;background:rgba(0,0,0,0.01)'; d.insertBefore(ov, d.firstChild); }
          ov.addEventListener('click', closeAll);
          const c = d.querySelector('.close,[data-close],.btn-close');
          if(c) c.addEventListener('click', closeAll);
        });
    }).observe(document.body,{childList:true,subtree:true});
  }

  function boot(){ dedupeBars(); enableMeEdit(); makeEngineClosable(); }
  document.addEventListener('DOMContentLoaded', boot);
  // keep deduping a while for SPA
  let n=0; const timer=setInterval(()=>{ dedupeBars(); if(++n>30) clearInterval(timer); }, 700);
})();




// === Close engine sheet when clicking outside ===
(function(){
  const sheet = document.getElementById('sheet');
  if (!sheet) return;
  // guard: avoid multiple bindings
  if (!window.__sheetOutsideCloseBound) {
    window.__sheetOutsideCloseBound = true;
    document.addEventListener('click', function(e){
      const isOpen = !sheet.classList.contains('hidden');
      if (!isOpen) return;
      const inside = sheet.contains(e.target);
      const triggers = e.target.closest && (e.target.closest('#btnManageEngine') || e.target.closest('.engine-item .edit'));
      if (!inside && !triggers) {
        try { closeSheet(); } catch(_) { sheet.classList.add('hidden'); }
      }
    }, true);
  }
})();
